package com.bank.customer.query;

import lombok.Value;

/**
 * VERB+NOUN+Query
 */
@Value
public class FindUpdateMobileSagaQuery {

}
