package com.bank.cards.query;

import lombok.Value;

@Value
public class FindCardQuery {
    private final String mobileNumber;
}
