package com.bank.loans.query;

import lombok.Value;

@Value
public class FindLoanQuery {
    private final String mobileNumber;
}
