package com.bank.accounts.entity;

public enum Role {
    USER,
    ADMIN
}
