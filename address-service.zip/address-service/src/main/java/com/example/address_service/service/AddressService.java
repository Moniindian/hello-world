package com.example.address_service.service;

import com.example.address_service.exception.ResourceNotFoundException;
import com.example.address_service.model.Address;
import com.example.address_service.repository.AddressRepo;
import com.example.address_service.response.AddressResponse;
import jakarta.transaction.Transactional;
import org.modelmapper.ModelMapper;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class AddressService {
    @Autowired
    private AddressRepo addressRepo;

    public List<AddressResponse> getAllAddresses() {
        return addressRepo.findAll().stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public AddressResponse getAddressById(Integer id) {
        Address address = addressRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Address not found with id: " + id));
        return convertToDTO(address);
    }

    public List<AddressResponse> getAddressesByCity(String city) {
        return addressRepo.findByCity(city).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    public List<AddressResponse> getAddressesByState(String state) {
        return addressRepo.findByState(state).stream()
                .map(this::convertToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public AddressResponse createAddress(AddressResponse addressDTO) {
        Address address = convertToEntity(addressDTO);
        Address savedAddress = addressRepo.save(address);
        return convertToDTO(savedAddress);
    }

    @Transactional
    public AddressResponse updateAddress(Integer id, AddressResponse addressDTO) {
        Address existingAddress = addressRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Address not found with id: " + id));

        BeanUtils.copyProperties(addressDTO, existingAddress, "id");
        Address updatedAddress = addressRepo.save(existingAddress);
        return convertToDTO(updatedAddress);
    }

    @Transactional
    public void deleteAddress(Integer id) {
        if (!addressRepo.existsById(id)) {
            throw new RuntimeException("Address not found with id: " + id);
        }
        addressRepo.deleteById(id);
    }

    private AddressResponse convertToDTO(Address address) {
        AddressResponse addressDTO = new AddressResponse();
        BeanUtils.copyProperties(address, addressDTO);
        return addressDTO;
    }

    private Address convertToEntity(AddressResponse addressDTO) {
        Address address = new Address();
        BeanUtils.copyProperties(addressDTO, address);
        return address;
    }
}