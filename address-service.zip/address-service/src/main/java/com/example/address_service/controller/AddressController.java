package com.example.address_service.controller;

import com.example.address_service.model.Address;
import com.example.address_service.response.AddressResponse;
import com.example.address_service.service.AddressService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/addresses")
public class AddressController {

    @Autowired
    private AddressService addressService;

    @GetMapping
    public ResponseEntity<List<AddressResponse>> getAllAddresses() {
        return ResponseEntity.ok(addressService.getAllAddresses());
    }

    @GetMapping("/{id}")
    public ResponseEntity<AddressResponse> getAddressById(@PathVariable Integer id) {
        return ResponseEntity.ok(addressService.getAddressById(id));
    }

    @GetMapping("/city/{city}")
    public ResponseEntity<List<AddressResponse>> getAddressesByCity(@PathVariable String city) {
        return ResponseEntity.ok(addressService.getAddressesByCity(city));
    }

    @GetMapping("/state/{state}")
    public ResponseEntity<List<AddressResponse>> getAddressesByState(@PathVariable String state) {
        return ResponseEntity.ok(addressService.getAddressesByState(state));
    }

    @PostMapping
    public ResponseEntity<AddressResponse> createAddress( @RequestBody AddressResponse addressDTO) {
        AddressResponse createdAddress = addressService.createAddress(addressDTO);
        return new ResponseEntity<>(createdAddress, HttpStatus.CREATED);
    }

    @PutMapping("/{id}")
    public ResponseEntity<AddressResponse> updateAddress(
            @PathVariable Integer id,
            @RequestBody AddressResponse addressDTO) {
        return ResponseEntity.ok(addressService.updateAddress(id, addressDTO));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteAddress(@PathVariable Integer id) {
        addressService.deleteAddress(id);
        return ResponseEntity.noContent().build();
    }
}

