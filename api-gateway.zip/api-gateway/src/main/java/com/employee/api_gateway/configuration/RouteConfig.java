package com.employee.api_gateway.configuration;

import org.springframework.cloud.gateway.route.RouteLocator;
import org.springframework.cloud.gateway.route.builder.RouteLocatorBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class RouteConfig {

    @Bean
    public RouteLocator customRouteLocator(RouteLocatorBuilder builder) {
        return builder.routes()
                .route("employee-service", r -> r
                        .path("/api/employees/**")
                        .filters(f -> f
                                .circuitBreaker(config -> config
                                        .setName("employeeService")
                                        .setFallbackUri("forward:/employee-fallback"))
                        )
                        .uri("http://localhost:8081"))
                .route("address-service", r -> r
                        .path("/api/addresses/**")
                        .filters(f -> f
                                .circuitBreaker(config -> config
                                        .setName("addressService")
                                        .setFallbackUri("forward:/address-fallback"))
                        )
                        .uri("http://localhost:8082/address-service"))
                .build();
    }
}