package com.employee.api_gateway.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class FallbackController {

    @GetMapping("/employee-fallback")
    public ResponseEntity<String> employeeServiceFallback() {
        return ResponseEntity.ok("Employee Service is taking longer than expected. Please try again later.");
    }

    @GetMapping("/address-fallback")
    public ResponseEntity<String> addressServiceFallback() {
        return ResponseEntity.ok("Address Service is taking longer than expected. Please try again later.");
    }
}
