package com.example.employee_service.service;

import com.example.employee_service.response.EmployeeResponse;
import com.example.employee_service.model.Employee;
import com.example.employee_service.repository.EmployeeRepository;
import com.example.employee_service.response.AddressResponse;
import org.modelmapper.ModelMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.reactive.function.client.WebClient;
import reactor.core.publisher.Mono;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class EmployeeService {

    @Autowired
    private EmployeeRepository employeeRepo;

    @Autowired
    private WebClient webClient;

    private static final Logger logger = LoggerFactory.getLogger(EmployeeService.class);

    public List<EmployeeResponse> getAllEmployees() {
        return employeeRepo.findAll().stream()
                .map(this::getEmployeeWithAddress)
                .collect(Collectors.toList());
    }

    public EmployeeResponse getEmployeeById(int id) {
        Employee employee = employeeRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with id: " + id));
        return getEmployeeWithAddress(employee);
    }

    public Employee createEmployee(Employee employee) {
        return employeeRepo.save(employee);
    }

    public Employee updateEmployee(int id, Employee employeeDetails) {
        Employee employee = employeeRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with id: " + id));

        employee.setName(employeeDetails.getName());
        employee.setEmail(employeeDetails.getEmail());
        employee.setAge(employeeDetails.getAge());

        return employeeRepo.save(employee);
    }

    public void deleteEmployee(int id) {
        Employee employee = employeeRepo.findById(id)
                .orElseThrow(() -> new RuntimeException("Employee not found with id: " + id));
        employeeRepo.delete(employee);
    }

    private EmployeeResponse getEmployeeWithAddress(Employee employee) {
        EmployeeResponse response = EmployeeResponse.fromEmployee(employee);

        try {

            AddressResponse address = webClient.get()
                    .uri("/" + employee.getId())  // Updated URI
                    .retrieve()
                    .bodyToMono(AddressResponse.class)
                    .onErrorResume(error -> {
                        logger.error("Error fetching address: ", error);
                        return Mono.empty();
                    })
                    .block();

            response.setAddressResponse(address);  // Updated setter name
        } catch (Exception e) {
            logger.error("Error in getEmployeeWithAddress: ", e);
        }
        return response;
    }


}